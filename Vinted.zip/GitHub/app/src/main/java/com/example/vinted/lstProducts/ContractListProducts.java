package com.example.vinted.lstProducts;

public interface ContractListProducts {
    
    public interface View{
        
    }
    public interface Presenter  {
        
    }
    public interface Model{
        
    }
}
