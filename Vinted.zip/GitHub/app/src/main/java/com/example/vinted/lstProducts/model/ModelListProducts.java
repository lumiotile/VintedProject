package com.example.vinted.lstProducts.model;

import com.example.vinted.lstProducts.ContractListProducts;

public class ModelListProducts implements ContractListProducts.Model {

    
}
