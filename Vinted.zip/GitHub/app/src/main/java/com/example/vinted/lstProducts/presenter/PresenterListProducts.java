package com.example.vinted.lstProducts.presenter;

import com.example.vinted.lstProducts.ContractListProducts;

public class PresenterListProducts implements ContractListProducts.Presenter {
}
